#!/bin/bash

vrunner designer --no-wait "$@"